document.addEventListener("DOMContentLoaded", function() {
    let budget = 0;
    let totalExpenses = 0;
    const expenses = [];

    const budgetInput = document.getElementById("budget-input");
    const setBudgetBtn = document.getElementById("set-budget-btn");
    const budgetMessage = document.getElementById("budget-message");
    const expenseCategory = document.getElementById("expense-category");
    const customCategoryInput = document.getElementById("custom-category-input");
    const expenseInput = document.getElementById("expense-input");
    const addExpenseBtn = document.getElementById("add-expense-btn");
    const expensesUl = document.getElementById("expenses-ul");
    const totalExpensesDisplay = document.getElementById("total-expenses");

    setBudgetBtn.addEventListener("click", function() {
        budget = parseFloat(budgetInput.value);
        if (isNaN(budget) || budget <= 0) {
            budgetMessage.textContent = "Please enter a valid budget.";
        } else {
            budgetMessage.textContent = `Budget set to $${budget.toFixed(2)}`;
            budgetInput.value = '';
        }
    });

    expenseCategory.addEventListener("change", function() {
        if (expenseCategory.value === "Custom") {
            customCategoryInput.style.display = "block";
        } else {
            customCategoryInput.style.display = "none";
            customCategoryInput.value = '';
        }
    });

    addExpenseBtn.addEventListener("click", function() {
        const expenseAmount = parseFloat(expenseInput.value);
        let category = expenseCategory.value;

        if (category === "Custom") {
            category = customCategoryInput.value;
        }

        if (isNaN(expenseAmount) || expenseAmount <= 0) {
            alert("Please enter a valid expense amount.");
            return;
        }

        if (category === "" && expenseCategory.value === "Custom") {
            alert("Please enter a custom category name.");
            return;
        }

        expenses.push({ category, amount: expenseAmount });
        totalExpenses += expenseAmount;
        
        const listItem = document.createElement("li");
        listItem.textContent = `${category}: $${expenseAmount.toFixed(2)}`;
        expensesUl.appendChild(listItem);

        totalExpensesDisplay.textContent = `Total Expenses: $${totalExpenses.toFixed(2)}`;

        expenseInput.value = '';
        customCategoryInput.value = '';
        expenseCategory.value = "Food"; // Reset to default
        customCategoryInput.style.display = "none"; // Hide custom input
    });
});
